# -*- coding: utf-8 -*-
# !/usr/bin/python2.7

import os
import requests
import time
import json
import ConfigParser

__author__ = 'WendyYu'


class LampTest:

    def __init__(self, bridge_ip=None, username=None):
        """
        Version: v1.0.0
        :param bridge_ip and username: default is None, get them from bridge.cfg file
        :return: None
        """
        if bridge_ip is not None and username is not None:
            self._ip = bridge_ip
            self._user = username
        else:
            cf = ConfigParser.ConfigParser()
            cf.read("bridge.cfg")
            self._ip = cf.get('Config', 'BridgeIp')
            self._user = cf.get('Config', 'ValidUser')
        self._pre_url = "http://" + self._ip + "/api/" + self._user
        self._sceneID = ''
        self._scene_body = ''
        self.msg_list = []
        # information = '='*120 + '\n'*2 + '\t'*3+"BridgeIp: "+self._ip+'\n'+'\t'*3+"UserName: "+self._user \
        #               + '\n'*2 + '=' * 120
        # self.msg_list.append(information)
        self._day = time.strftime("%Y-%m-%d", time.localtime())
        self._day = time.strftime("%Y-%m-%d", time.localtime())

    def command(self, method, suffix_url=None, body=None):
        """
        :param method: "get", "put","post","delete"(upper or lower case are all Ok)
        :param suffix_url: it is like "/groups/0/action"
        :param body: The format for body is just like {"on":True}
                 => Attention: if use true or false for on, please capitalize the first letter
        :return: "Error" if not successful else return None
        """
        if suffix_url is not None:
            url = self._pre_url + suffix_url
        else:
            url = self._pre_url
        # print url + '\t' + method
        real_time = time.strftime("%H:%M:%S", time.localtime())
        self.msg_list.append('\n' * 2 + self._day + '\t' + real_time + '\n' + '\t' * 2 + suffix_url + '\t' + method.upper() +
                             '\n')
        if method.lower() == "get":
            response = requests.get(url)
        elif method.lower() == "post":
            if body is not None:
                # print json.dumps(body)
                self.msg_list.append('\t' * 2 + body + '\n')
                response = requests.post(url, body)
            else:
                response = requests.post(url)
        elif method.lower() == "delete":
            response = requests.delete(url)
        elif method.lower() == 'put':
            if body is None:
                response = requests.put(url)
            else:
                # print json.dumps(body)
                self.msg_list.append('\t' * 2 + body + '\n')
                response = requests.put(url, body)
        else:
            print "Error: Input wrong method\n"
            return None
        return response.text

    def write_log_all(self, file_name, path, msg_list=None):
        """
        :param file_name: file name for log
        :param path: Path for log
        :param msg_list: Default is none, the mes_lisg generate by this class
        :return: "Error" if not successful else return None
        """
        random_num = time.strftime("%H%M%S", time.localtime())
        if path:
            if os.path.exists(path) == 0:
                os.makedirs(path)
            file_path = os.path.join(path, file_name)
            logfile = open("%s_%s_%s.log" % (file_path, self._day, random_num), 'w')
            information = '='*120 + '\n'*2 + '\t'*3+"BridgeIp: "+self._ip+'\n'+'\t'*3+"UserName: "+self._user + '\n'*2 + '=' * 120
            logfile.write(information)
        if msg_list is None:
            msg_list = self.msg_list
        for msg in msg_list:
            logfile.write(msg)
            logfile.flush()
        self.msg_list = []
        logfile.write('\n'*2+"Finished Test")
        logfile.close()

    def uni_cast(self, method, lights_list, body=None):
        """
        :param method: 'put','delete','get','post'(Upper or lower case are all Ok)
        :param lights_list: it is just like [1,2,3]
        :param body: The format for body is just like {"on":True}
                 => Attention: if use true or false for on, please capitalize the first letter
        :return: "Error" if not successful else return None
        """
        if lights_list:
            for light in lights_list:
                append_url = '/lights/' + str(light)
                if method.lower() == 'put' and body is not None:
                    put_suffix_url = append_url + '/state'
                    response = self.command(method, put_suffix_url, body)
                else:
                    response = self.command(method, append_url)
                real_time = time.strftime("%H:%M:%S", time.localtime())
                # print response+'\n'
                self.msg_list.append('\t' + real_time + '\n' + '\t' * 2 + response + '\n')
                if "error" in response.lower():
                    return "Error"
                time.sleep(1)

    def group_cast(self, method, group_num=None, body=None):
        """
        :param method: 'put','delete','get','post'(Upper or lower case are all Ok)
        :param group_num: group number
        :param body: The format for body is just like {"on":True}
                 => Attention: if use true or false for on, please capitalize the first letter
        :return: "Error" if not successful else return None
        """
        if group_num is None:
            append_url = '/groups'
        else:
            append_url = '/groups/'+str(group_num)
        if method.lower() == 'put' and body is not None:
            put_suffix_url = append_url + '/action'
            response = self.command(method, put_suffix_url, body)
        else:
            response = self.command(method)
        real_time = time.strftime("%H:%M:%S", time.localtime())
        # print response+'\n'
        self.msg_list.append('\t' + real_time + '\n' + '\t' * 2 + response + '\n')
        if "error" in response.lower():
            return "Error"

    def create_scene(self, scene_name, lights_list, light_body=None, set_in_background=True):
        """
        :param scene_name: The name for the scene
        :param lights_list: it is just like [1,2,3]
        :param light_body:  The format for body is just like {"on":True}
                        => Attention: if use true or false for on, please capitalize the first letter
        :param set_in_background: True or False, default is True
        :return:"Error" if not successful else return None
        """
        str_lights_list = []
        for light in lights_list:
            str_lights_list.append(str(light))
        scene_append_url = '/scenes'
        self._scene_body = '{"name":"%s","lights":%s}' % (scene_name, json.dumps(str_lights_list))
        scene_response = self.command("post", scene_append_url, self._scene_body)
        real_time = time.strftime("%H:%M:%S", time.localtime())
        print scene_response + '\n'
        self.msg_list.append('\t' + real_time + '\n' + '\t' * 2 + scene_response + '\n')
        if "success" in scene_response.lower():
            index_sceneid_begin = scene_response.find('id')
            index_sceneid_begin += 5
            index_sceneid_end = scene_response.find('"}')
            self._sceneID = scene_response[index_sceneid_begin: index_sceneid_end]
        if set_in_background is True and light_body is not None:
            for light in lights_list:
                suffix_url = "/scenes/%s/lightstates/%s" % (self._sceneID, str(light))
                response = self.command("PUT", suffix_url, light_body)
                # print response
                self.msg_list.append('\t' + real_time + '\n' + '\t' * 2 + response + '\n')
                if "error" in scene_response or "error" in response:
                    return "Error"
        elif set_in_background is False:
            return None
        else:
            return "Error"

    def recall_scene(self, group_num, scene_id=None):
        """
        Recall the existed scene
        :param group_num: group number for the recalled scene
        :param scene_id: if not set it, using scene Id in create_scene operation
                        set the scene_id for the one recalled (scene_id must exist)
        :return: "Error" if not successful else return None
        """
        if scene_id is None:
            body = '{"scene":"%s"}' % self._sceneID
        else:
            body = '{"scene":"%s"}' % scene_id
        suffix_url = '/groups/%s/action' % str(group_num)
        recall_response = self.command("PUT", suffix_url, body)
        real_time = time.strftime("%H:%M:%S", time.localtime())
        # print recall_response + '\n'
        self.msg_list.append('\t' + real_time + '\n' + '\t' * 2 + recall_response + '\n')
        if "error" in recall_response.lower():
            return "Error"

    def scene_operation(self, operate, body=None, scene_id=None):
        """
        scene_operation include get scene details, delete scene and modify scene
        :param operate: "get" and "delete", others are invalid
        :param body: The format for body is just like {"on":True}
                 => Attention: if use true or false for on, please capitalize the first letter
        :param scene_id: if not set it, using scene Id in create_scene operation
                        set the scene_id for the one delete or Get details (scene_id must exist)
        :return: "Error" if not successful else return None
        """
        if scene_id is None:
            scene_suffix_url = "/scenes/%s" % self._sceneID
        else:
            scene_suffix_url = "/scenes/%s" % scene_id
        operate_response = self.command(operate, scene_suffix_url, json.loads(body))
        print operate_response + '\n'
        if "error" in operate_response:
            return "Error"

    def read_attribute_value(self, attribute, lights_list):
        """
        :param attribute: "bri","ct","xy","hue" or "sat", set one for this parameter
        :param lights_list: All the light which need to know the value
        :return: The value for the light
        """
        real_time = time.strftime("%H:%M:%S", time.localtime())
        self.msg_list.append('\n' * 2 + self._day + '\t' + real_time + "\n\t\tLight\t\t|\t\t%s\n" % attribute)
        for light in lights_list:
            response = requests.get(self._pre_url + "/lights/%s" % light).text
            # response = self.command("get", "/lights/%s" % light)
            if attribute in response:
                response_list = response.split(",")
                l = len(response_list)
                for i in range(l):
                    find_string = json.dumps(attribute) + ":"
                    length = len(find_string)
                    if find_string in response_list[i]:
                        s_id = response_list[i].index(find_string) + length
                        read_value = response_list[i][s_id:]
                        if attribute is "xy":
                            read_value = response_list[i][s_id:] + ", " + response_list[i+1]
                        print "\nLight %s %s" % (light, find_string + read_value)
                        self.msg_list.append("\t\t%5s\t\t|\t\t%s\n" % (light, read_value))

    def read_attributes_values(self, string, lights_list):
        attributes = ["bri", "ct", "xy", "hue", "sat"]
        for attribute in attributes:
            find_attribute = json.dumps(attribute) + ":"
            if find_attribute in string:
                time.sleep(10)
                self.read_attribute_value(attribute, lights_list)

    def init_lamp(self, group_num):
        initialize_body = {"on": True, "bri": 254, "ct": 333}
        url = self._pre_url + "/groups/%s/action" % str(group_num)
        requests.put(url, json.dumps(initialize_body))

    def effect_none(self, group_num):
        effect_body = {"effect": "none"}
        url = self._pre_url + "/groups/%s/action" % str(group_num)
        requests.put(url, json.dumps(effect_body))
